# magnetic ordering:
MAGMOM = 3 -3 -3 3  8*0