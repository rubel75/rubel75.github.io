Here we collected VASP structure files of relevant materials.
The files can be opened with VESTA  visualization program for structural models (https://jp-minerals.org/vesta/en/).