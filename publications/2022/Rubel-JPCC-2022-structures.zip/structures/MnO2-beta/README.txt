# magnetic ordering:
MAGMOM = 2  -2  4*0