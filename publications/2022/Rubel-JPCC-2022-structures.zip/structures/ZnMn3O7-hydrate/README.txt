# magnetic ordering:
MAGMOM = 18*3  6*0   60*0   36*0