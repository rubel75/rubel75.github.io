# magnetic ordering:
MAGMOM = 3 3 -3 -3 3 3 -3 -3 16*0